
<?php $__env->startSection('container'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
<h1 class="h3 mb-0 text-gray-800">Laporan Penyewaan Mobil</h1>
</div><hr>
<div class="card-header py-3" align="right">
<a href="/laporan/print" class="d-none d-sm-inline-block btn  btn-primary shadow-sm">
<i class="fa fa-print  text-white-50"></i> Print</a>
</div>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
<div class="card-body">
<div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
<thead>
<tr align="center">
                        <th>Nomor Penyewaan</th>
                        <th>Customer</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Harga</th>
                        <th>Jenis Pembayaran</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $penyewaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pny): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($pny->nomor_penyewaan); ?></td>
<td><?php echo e($pny->customer_name); ?></td>
<td><?php echo e($pny->tanggal_pinjam); ?></td>
<td><?php echo e($pny->tanggal_kembali); ?></td>
<td><?php echo e($pny->harga); ?></td>
<td><?php echo e($pny->jenis_pembayaran); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\rental-car-laravel-crud\resources\views/laporan/index.blade.php ENDPATH**/ ?>