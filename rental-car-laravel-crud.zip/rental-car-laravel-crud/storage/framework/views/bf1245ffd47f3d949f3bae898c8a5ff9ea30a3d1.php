
<?php $__env->startSection('container'); ?>
    

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center p2-3 pb-2 mb-3 border-bottom">
  <h2 class="h2">Data Penyewaan</h1>

</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form class="form-inline">
            
            
            <a href="/penyewaan/create" class="btn btn-primary mb-2">Tambah</a>
          </form>
        
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Nomor</th>
                        <th>Customer</th>
                        <th>Mobil</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Harga</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $penyewaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penyewaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($penyewaan->nomor_penyewaan); ?></td>
                        <td><?php echo e($penyewaan->customer_name); ?></td>
                        <td><?php echo e($penyewaan->mobil_name); ?></td>
                        <td><?php echo e($penyewaan->tanggal_pinjam); ?></td>
                        <td><?php echo e($penyewaan->tanggal_kembali); ?></td>
                        <td><?php echo e($penyewaan->harga); ?></td>
                        <td class="text-center">
                        
                        <a href="/penyewaan/edit/<?php echo e($penyewaan->id); ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
                        <form action="/penyewaan/delete/<?php echo e($penyewaan->id); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>    
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>   
                        </form> 
                        </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\rental-car-laravel-crud\resources\views/penyewaan/index.blade.php ENDPATH**/ ?>