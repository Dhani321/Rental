
<?php $__env->startSection('container'); ?>
    

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center p2-3 pb-2 mb-3 border-bottom">
  <h2 class="h2">Tambah Mobil</h1>

</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form action="/mobil/update/<?php echo e($mobil->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
             <div class="col-lg-6">
                <img src="/upload_files/<?php echo e($mobil->image); ?>" class="img-fluid" width="500px" alt="">
             </div>
             <div class="col-lg-6">
              <div class="form-group col-md-6">
                <label >Merk</label>
                <select name="merk_id" class="form-control"  disabled>
                  <option selected>Choose...</option>
                    <?php $__currentLoopData = $merks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($merk->id); ?>" <?php echo e(($mobil->merk_id == $merk->id) ? 'selected' : ''); ?>><?php echo e($merk->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label >Nama</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($mobil->name); ?>" required  disabled>
              </div>
              <div class="form-group col-md-6">
                <label >Warna</label>
                <select name="warna" class="form-control"  disabled>
                  <option selected>Choose...</option>
                      <option value="Merah" <?php echo e(($mobil->warna == 'Merah') ? 'selected' : ''); ?>>Merah</option>
                      <option value="Kuning" <?php echo e(($mobil->warna == 'Kuning') ? 'selected' : ''); ?>>Kuning</option>
                      <option value="Hitam" <?php echo e(($mobil->warna == 'Hitam') ? 'selected' : ''); ?>>Hitam</option>
                      <option value="Putih" <?php echo e(($mobil->warna == 'Putih') ? 'selected' : ''); ?>>Putih</option>
                      <option value="Grey" <?php echo e(($mobil->warna == 'Grey') ? 'selected' : ''); ?>>Grey</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label >Plat Nomor</label>
                <input type="text" class="form-control" value="<?php echo e($mobil->plat_nomor); ?>" name="plat_nomor" required  disabled>
              </div>
              <div class="form-group col-lg-6">
                <label >Tahun Beli</label>
                <input type="number" class="form-control" name="tahun_beli" value="<?php echo e($mobil->tahun_beli); ?>" min="2000" max="2022" required  disabled> 
              </div>
             
              
           
             </div>
            </div>
          
          
            
            <a href="/mobil" class="btn btn-warning mt-2">Kembali</a>
          </form>
        
      
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\rental-car-laravel-crud\resources\views/mobil/show.blade.php ENDPATH**/ ?>