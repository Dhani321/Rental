
<?php $__env->startSection('container'); ?>
    

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center p2-3 pb-2 mb-3 border-bottom">
  <h2 class="h2">Merk</h1>

</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form class="form-inline">
            
            
            <a href="/merk/create" class="btn btn-primary mb-2">Tambah</a>
          </form>
        
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Merk</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $merks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($merk->name); ?></td>
                        <td class="text-center">
                        <a href="/merk/edit/<?php echo e($merk->id); ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
                        <form action="/merk/delete/<?php echo e($merk->id); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>    
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>   
                        </form> 
                        </td> 
                     
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\rental-car-laravel-crud\resources\views/merk/index.blade.php ENDPATH**/ ?>