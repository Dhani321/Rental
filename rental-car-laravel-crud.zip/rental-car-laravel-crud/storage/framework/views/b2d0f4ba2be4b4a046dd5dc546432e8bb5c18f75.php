
<?php $__env->startSection('container'); ?>
    

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center p2-3 pb-2 mb-3 border-bottom">
  <h2 class="h2">Data Mobil</h1>

</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form class="form-inline">
            
            
            <a href="/mobil/create" class="btn btn-primary mb-2">Tambah</a>
          </form>
        
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Merk</th>
                        <th>Nama</th>
                        <th>Warna</th>
                        <th>Plat Nomor</th>
                        <th>Tahun Beli</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($mobil->merk_id); ?></td>
                        <td><?php echo e($mobil->name); ?></td>
                        <td><?php echo e($mobil->warna); ?></td>
                        <td><?php echo e($mobil->plat_nomor); ?></td>
                        <td><?php echo e($mobil->tahun_beli); ?></td>
                        <td class="text-center">
                        <a href="/mobil/show/<?php echo e($mobil->id); ?>" class="btn btn-dark"><i class="fas fa-eye"></i></a>
                        <a href="/mobil/edit/<?php echo e($mobil->id); ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
                        <form action="/mobil/delete/<?php echo e($mobil->id); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>    
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>   
                        </form> 
                        </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\rental-car-laravel-crud\resources\views/mobil/index.blade.php ENDPATH**/ ?>